Images are formatted for 63x88mm cards with generous borders to allow for slight offset errors during the printing process.

I use https://www.makeplayingcards.com/ S30 Standard.